
// Database abstraction layer for GroupMates
class DatabaseManager {
    constructor() {
        this.isProduction = window.location.hostname !== 'localhost' && !window.location.hostname.includes('replit.dev');
        this.apiBase = this.isProduction ? '/api' : 'http://localhost:3001/api';
    }

    // User management
    async createUser(userData) {
        if (this.isProduction) {
            const response = await fetch(`${this.apiBase}/users`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
            return response.json();
        } else {
            // Fallback to localStorage for development
            const users = JSON.parse(localStorage.getItem('registeredUsers') || '{}');
            users[userData.phone] = userData;
            localStorage.setItem('registeredUsers', JSON.stringify(users));
            return userData;
        }
    }

    async getUser(phone) {
        if (this.isProduction) {
            const response = await fetch(`${this.apiBase}/users/${phone}`);
            return response.json();
        } else {
            const users = JSON.parse(localStorage.getItem('registeredUsers') || '{}');
            return users[phone] || null;
        }
    }

    async updateUser(phone, updates) {
        if (this.isProduction) {
            const response = await fetch(`${this.apiBase}/users/${phone}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updates)
            });
            return response.json();
        } else {
            const users = JSON.parse(localStorage.getItem('registeredUsers') || '{}');
            if (users[phone]) {
                users[phone] = { ...users[phone], ...updates };
                localStorage.setItem('registeredUsers', JSON.stringify(users));
            }
            return users[phone];
        }
    }

    // SMS verification
    async sendVerificationSMS(phone) {
        if (this.isProduction) {
            const response = await fetch(`${this.apiBase}/sms/send-verification`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ phone })
            });
            return response.json();
        } else {
            // Development: Generate mock code
            const code = Math.floor(100000 + Math.random() * 900000).toString();
            console.log(`Mock SMS to ${phone}: ${code}`);
            return { success: true, message: 'SMS sent', mockCode: code };
        }
    }

    async verifyCode(phone, code) {
        if (this.isProduction) {
            const response = await fetch(`${this.apiBase}/sms/verify`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ phone, code })
            });
            return response.json();
        } else {
            // Development: Always return true for demo
            return { success: true, verified: true };
        }
    }

    // Analytics
    async trackEvent(eventData) {
        if (this.isProduction) {
            fetch(`${this.apiBase}/analytics/track`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(eventData)
            }).catch(err => console.error('Analytics tracking failed:', err));
        } else {
            // Fallback to localStorage
            const analytics = JSON.parse(localStorage.getItem('analytics') || '{}');
            if (!analytics.events) analytics.events = [];
            analytics.events.push(eventData);
            localStorage.setItem('analytics', JSON.stringify(analytics));
        }
    }

    // Location and matching
    async findNearbyUsers(userLocation, radius = 10) {
        if (this.isProduction) {
            const response = await fetch(`${this.apiBase}/users/nearby`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ location: userLocation, radius })
            });
            return response.json();
        } else {
            // Return mock data for development
            return this.generateMockNearbyUsers();
        }
    }

    generateMockNearbyUsers() {
        const mockNames = [
            'Alex Runner', 'Jordan Hiker', 'Casey Cyclist', 'Morgan Climber',
            'Taylor Swimmer', 'Riley Skater', 'Quinn Dancer', 'Avery Walker'
        ];

        const interests = [
            ['fitness', 'running'], ['hiking', 'yoga'], ['cycling', 'sports'],
            ['swimming', 'dancing'], ['fitness', 'hiking'], ['running', 'cycling']
        ];

        const users = [];
        const numUsers = Math.floor(Math.random() * 6) + 2;

        for (let i = 0; i < numUsers; i++) {
            users.push({
                id: 'user_' + Math.random().toString(36).substr(2, 9),
                name: mockNames[Math.floor(Math.random() * mockNames.length)],
                distance: (Math.random() * 5 + 0.1).toFixed(1),
                lastSeen: Math.floor(Math.random() * 60) + 1,
                verified: Math.random() > 0.3,
                interests: interests[Math.floor(Math.random() * interests.length)]
            });
        }

        return users.sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance));
    }

    // Connection management
    async sendConnectionRequest(fromUser, toUser) {
        if (this.isProduction) {
            const response = await fetch(`${this.apiBase}/connections/request`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ from: fromUser, to: toUser })
            });
            return response.json();
        } else {
            // Mock implementation
            const pendingRequests = JSON.parse(localStorage.getItem('pendingRequests') || '{}');
            pendingRequests[toUser.id] = {
                name: toUser.name,
                timestamp: Date.now(),
                status: 'sent'
            };
            localStorage.setItem('pendingRequests', JSON.stringify(pendingRequests));
            return { success: true };
        }
    }

    // Error logging
    async logError(error, context) {
        const errorData = {
            message: error.message || error,
            stack: error.stack,
            context: context,
            timestamp: Date.now(),
            userAgent: navigator.userAgent,
            url: window.location.href
        };

        if (this.isProduction) {
            fetch(`${this.apiBase}/errors/log`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(errorData)
            }).catch(err => console.error('Error logging failed:', err));
        } else {
            console.error('Error logged:', errorData);
        }
    }
}

// Initialize database manager
window.dbManager = new DatabaseManager();
