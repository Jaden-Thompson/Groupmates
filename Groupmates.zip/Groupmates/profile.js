
class ProfileManager {
    constructor() {
        this.currentStream = null;
        this.profilePhoto = null;
        this.verificationPhoto = null;
        this.isVerified = false;
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadExistingProfile();
    }

    bindEvents() {
        // Photo upload
        document.getElementById('photo-upload').addEventListener('change', (e) => {
            this.handlePhotoUpload(e);
        });

        // Camera controls
        document.getElementById('camera-btn').addEventListener('click', () => {
            this.startCamera();
        });

        document.getElementById('capture-btn').addEventListener('click', () => {
            this.capturePhoto();
        });

        document.getElementById('cancel-camera-btn').addEventListener('click', () => {
            this.stopCamera();
        });

        // Verification controls
        document.getElementById('start-verification-btn').addEventListener('click', () => {
            this.startVerification();
        });

        document.getElementById('verify-capture-btn').addEventListener('click', () => {
            this.captureVerification();
        });

        document.getElementById('cancel-verification-btn').addEventListener('click', () => {
            this.stopVerification();
        });

        // Profile actions
        document.getElementById('save-profile-btn').addEventListener('click', () => {
            this.saveProfile();
        });

        document.getElementById('skip-profile-btn').addEventListener('click', () => {
            this.skipProfile();
        });
    }

    handlePhotoUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        // Validate file type
        if (!file.type.startsWith('image/')) {
            alert('Please select a valid image file');
            return;
        }

        // Validate file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            alert('Image must be smaller than 5MB');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            this.profilePhoto = e.target.result;
            this.displayPhoto(e.target.result);
            this.showVerificationSection();
        };
        reader.readAsDataURL(file);
    }

    displayPhoto(dataUrl) {
        const placeholder = document.querySelector('.photo-placeholder');
        const profileImage = document.getElementById('profile-image');
        
        placeholder.style.display = 'none';
        profileImage.src = dataUrl;
        profileImage.classList.remove('hidden');
    }

    async startCamera() {
        try {
            this.currentStream = await navigator.mediaDevices.getUserMedia({ 
                video: { 
                    width: 640, 
                    height: 480,
                    facingMode: 'user' // Front camera for selfies
                } 
            });
            
            const video = document.getElementById('camera-video');
            video.srcObject = this.currentStream;
            
            document.getElementById('camera-section').classList.remove('hidden');
        } catch (error) {
            console.error('Error accessing camera:', error);
            alert('Unable to access camera. Please check permissions and try again.');
        }
    }

    capturePhoto() {
        const video = document.getElementById('camera-video');
        const canvas = document.getElementById('camera-canvas');
        const ctx = canvas.getContext('2d');
        
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        
        // Flip horizontally for selfie effect
        ctx.scale(-1, 1);
        ctx.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
        
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        this.profilePhoto = dataUrl;
        this.displayPhoto(dataUrl);
        this.stopCamera();
        this.showVerificationSection();
    }

    stopCamera() {
        if (this.currentStream) {
            this.currentStream.getTracks().forEach(track => track.stop());
            this.currentStream = null;
        }
        document.getElementById('camera-section').classList.add('hidden');
    }

    showVerificationSection() {
        document.getElementById('verification-section').classList.remove('hidden');
    }

    async startVerification() {
        try {
            this.currentStream = await navigator.mediaDevices.getUserMedia({ 
                video: { 
                    width: 640, 
                    height: 480,
                    facingMode: 'user'
                } 
            });
            
            const video = document.getElementById('verification-video');
            video.srcObject = this.currentStream;
            
            document.getElementById('verification-camera').classList.remove('hidden');
            document.getElementById('start-verification-btn').classList.add('hidden');
        } catch (error) {
            console.error('Error accessing camera for verification:', error);
            alert('Unable to access camera for verification. Please check permissions.');
        }
    }

    captureVerification() {
        const video = document.getElementById('verification-video');
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        
        // Flip horizontally for selfie effect
        ctx.scale(-1, 1);
        ctx.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
        
        this.verificationPhoto = canvas.toDataURL('image/jpeg', 0.8);
        this.processVerification();
        this.stopVerification();
    }

    stopVerification() {
        if (this.currentStream) {
            this.currentStream.getTracks().forEach(track => track.stop());
            this.currentStream = null;
        }
        document.getElementById('verification-camera').classList.add('hidden');
    }

    processVerification() {
        // Simulate verification process
        const resultDiv = document.getElementById('verification-result');
        const statusText = document.getElementById('verification-status-text');
        
        resultDiv.classList.remove('hidden');
        statusText.textContent = 'Processing verification...';
        statusText.className = 'processing';
        
        // Simulate processing time
        setTimeout(() => {
            // Simple verification: check if we have both photos
            if (this.profilePhoto && this.verificationPhoto) {
                this.isVerified = true;
                statusText.textContent = '✅ Verification successful!';
                statusText.className = 'success';
            } else {
                statusText.textContent = '❌ Verification failed. Please try again.';
                statusText.className = 'error';
            }
        }, 2000);
    }

    getSelectedInterests() {
        const checkboxes = document.querySelectorAll('.interest-tag input[type="checkbox"]:checked');
        return Array.from(checkboxes).map(cb => cb.value);
    }

    saveProfile() {
        const bio = document.getElementById('bio').value.trim();
        const interests = this.getSelectedInterests();
        
        if (!this.profilePhoto) {
            alert('Please add a profile photo');
            return;
        }
        
        if (!this.isVerified) {
            alert('Please complete selfie verification');
            return;
        }
        
        const profileData = {
            photo: this.profilePhoto,
            verificationPhoto: this.verificationPhoto,
            bio: bio,
            interests: interests,
            verified: this.isVerified,
            createdAt: Date.now()
        };
        
        // Save to localStorage (in a real app, this would go to a server)
        localStorage.setItem('userProfile', JSON.stringify(profileData));
        
        alert('Profile saved successfully!');
        window.location.href = 'index.html';
    }

    skipProfile() {
        if (confirm('Are you sure you want to skip profile setup? You can always complete it later.')) {
            window.location.href = 'index.html';
        }
    }

    loadExistingProfile() {
        const saved = localStorage.getItem('userProfile');
        if (saved) {
            const profile = JSON.parse(saved);
            
            if (profile.photo) {
                this.profilePhoto = profile.photo;
                this.displayPhoto(profile.photo);
            }
            
            if (profile.bio) {
                document.getElementById('bio').value = profile.bio;
            }
            
            if (profile.interests) {
                profile.interests.forEach(interest => {
                    const checkbox = document.querySelector(`input[value="${interest}"]`);
                    if (checkbox) checkbox.checked = true;
                });
            }
            
            if (profile.verified) {
                this.isVerified = true;
                this.verificationPhoto = profile.verificationPhoto;
                const resultDiv = document.getElementById('verification-result');
                const statusText = document.getElementById('verification-status-text');
                resultDiv.classList.remove('hidden');
                statusText.textContent = '✅ Previously verified';
                statusText.className = 'success';
            }
        }
    }
}

// Initialize profile manager
const profileManager = new ProfileManager();
