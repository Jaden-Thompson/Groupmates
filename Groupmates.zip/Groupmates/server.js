
// Backend server for GroupMates production
const express = require('express');
const cors = require('cors');
const path = require('path');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static('.'));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// SMS Rate limiting (stricter)
const smsLimiter = rateLimit({
    windowMs: 5 * 60 * 1000, // 5 minutes
    max: 3, // limit to 3 SMS per 5 minutes
    message: 'Too many SMS requests, please wait before trying again.'
});

// In-memory storage (replace with real database in production)
let users = {};
let verificationCodes = {};
let analytics = [];
let connections = {};
let messages = {};

// Helper functions
function generateVerificationCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

function validatePhoneNumber(phone) {
    const cleaned = phone.replace(/\D/g, '');
    return cleaned.length >= 10 && cleaned.length <= 15;
}

function sanitizeInput(input) {
    if (typeof input === 'string') {
        return input.trim().slice(0, 500); // Limit length and trim
    }
    return input;
}

// API Routes

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: Date.now() });
});

// User management
app.post('/api/users', (req, res) => {
    try {
        const { phone, name, location } = req.body;
        
        if (!validatePhoneNumber(phone)) {
            return res.status(400).json({ error: 'Invalid phone number' });
        }

        const cleanPhone = phone.replace(/\D/g, '');
        const sanitizedName = sanitizeInput(name);

        if (!sanitizedName || sanitizedName.length < 2) {
            return res.status(400).json({ error: 'Invalid name' });
        }

        const userData = {
            id: 'user_' + cleanPhone + '_' + Date.now(),
            phone: cleanPhone,
            name: sanitizedName,
            location: location,
            createdAt: Date.now(),
            lastLogin: Date.now(),
            verified: true
        };

        users[cleanPhone] = userData;
        res.json({ success: true, user: userData });
    } catch (error) {
        console.error('User creation error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/users/:phone', (req, res) => {
    try {
        const phone = req.params.phone.replace(/\D/g, '');
        const user = users[phone];
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json(user);
    } catch (error) {
        console.error('User fetch error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// SMS verification
app.post('/api/sms/send-verification', smsLimiter, (req, res) => {
    try {
        const { phone } = req.body;
        
        if (!validatePhoneNumber(phone)) {
            return res.status(400).json({ error: 'Invalid phone number' });
        }

        const cleanPhone = phone.replace(/\D/g, '');
        const code = generateVerificationCode();
        
        // Store verification code (expires in 10 minutes)
        verificationCodes[cleanPhone] = {
            code: code,
            expires: Date.now() + 10 * 60 * 1000,
            attempts: 0
        };

        // TODO: Integrate with SMS service (Twilio, AWS SNS, etc.)
        console.log(`SMS to ${cleanPhone}: Your GroupMates verification code is ${code}`);
        
        res.json({ 
            success: true, 
            message: 'Verification code sent',
            // Remove this in production:
            mockCode: code 
        });
    } catch (error) {
        console.error('SMS send error:', error);
        res.status(500).json({ error: 'Failed to send SMS' });
    }
});

app.post('/api/sms/verify', (req, res) => {
    try {
        const { phone, code } = req.body;
        const cleanPhone = phone.replace(/\D/g, '');
        
        const stored = verificationCodes[cleanPhone];
        
        if (!stored) {
            return res.status(400).json({ error: 'No verification code found' });
        }

        if (Date.now() > stored.expires) {
            delete verificationCodes[cleanPhone];
            return res.status(400).json({ error: 'Verification code expired' });
        }

        stored.attempts += 1;
        
        if (stored.attempts > 5) {
            delete verificationCodes[cleanPhone];
            return res.status(429).json({ error: 'Too many attempts' });
        }

        if (stored.code !== code) {
            return res.status(400).json({ error: 'Invalid verification code' });
        }

        // Code is valid
        delete verificationCodes[cleanPhone];
        res.json({ success: true, verified: true });
    } catch (error) {
        console.error('SMS verify error:', error);
        res.status(500).json({ error: 'Verification failed' });
    }
});

// Analytics
app.post('/api/analytics/track', (req, res) => {
    try {
        const eventData = {
            ...req.body,
            ip: req.ip,
            userAgent: req.get('User-Agent'),
            timestamp: Date.now()
        };
        
        analytics.push(eventData);
        
        // Keep only last 10000 events in memory
        if (analytics.length > 10000) {
            analytics = analytics.slice(-10000);
        }
        
        res.json({ success: true });
    } catch (error) {
        console.error('Analytics error:', error);
        res.status(500).json({ error: 'Analytics tracking failed' });
    }
});

// Error logging
app.post('/api/errors/log', (req, res) => {
    try {
        const errorData = {
            ...req.body,
            ip: req.ip,
            timestamp: Date.now()
        };
        
        console.error('Client Error:', errorData);
        
        // TODO: Integrate with error monitoring service (Sentry, LogRocket, etc.)
        
        res.json({ success: true });
    } catch (error) {
        console.error('Error logging failed:', error);
        res.status(500).json({ error: 'Error logging failed' });
    }
});

// Serve static files
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`GroupMates server running on port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;
